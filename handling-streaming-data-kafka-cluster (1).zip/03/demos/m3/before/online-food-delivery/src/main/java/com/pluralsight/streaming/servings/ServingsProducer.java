package com.pluralsight.streaming.servings;

public class ServingsProducer {

    private static final Logger log = LoggerFactory.getLogger(ServingsProducer.class);
    private static final String SERVINGS_TOPIC = "servings";

    public static void main(String[] args) throws ExecutionException, InterruptedException {

    }
}
